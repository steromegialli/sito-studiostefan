import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import FaqAccordion from '@/components/FaqAccordion';
import CtaSection from '@/components/CtaSection';
import { faqData } from '@/constants/faqData';
import { generateFAQSchema } from '@/utils/seoHelpers';

const FaqPage = () => {
  return (
    <>
      <Helmet>
        <title>FAQ | Domande frequenti | Studio Romegialli Morbegno</title>
        <meta name="description" content="Domande frequenti sullo Studio Romegialli a Morbegno. Risposte su visite, trattamenti, costi, prenotazioni." />
        <link rel="canonical" href="https://studioromegialli.it/faq" />
        <script type="application/ld+json">
          {JSON.stringify(generateFAQSchema(faqData))}
        </script>
      </Helmet>

      <Header />

      <main className="pt-20">
        <section className="py-24 bg-gradient-to-b from-muted to-background">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance" style={{letterSpacing: '-0.02em'}}>
              Domande frequenti
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Trova le risposte alle domande più comuni sui nostri servizi.
            </p>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <FaqAccordion faqs={faqData} />
          </div>
        </section>

        <CtaSection
          title="Non hai trovato la risposta?"
          description="Contattaci per qualsiasi domanda. Saremo felici di aiutarti."
        />
      </main>

      <Footer />
    </>
  );
};

export default FaqPage;