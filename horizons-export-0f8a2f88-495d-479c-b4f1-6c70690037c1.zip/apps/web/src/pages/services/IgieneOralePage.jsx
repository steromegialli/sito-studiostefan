import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import FaqAccordion from '@/components/FaqAccordion';
import CtaSection from '@/components/CtaSection';

const IgieneOralePage = () => {
  const faqs = [
    {
      question: 'Ogni quanto fare la pulizia dei denti?',
      answer: 'Si consiglia una pulizia professionale ogni 6 mesi. In alcuni casi, come presenza di parodontite o predisposizione al tartaro, può essere necessaria una frequenza maggiore.'
    },
    {
      question: 'La pulizia dei denti fa male?',
      answer: 'La pulizia professionale è generalmente indolore. In caso di gengive sensibili o infiammate, si può avvertire un leggero fastidio, ma il trattamento è ben tollerato.'
    },
    {
      question: 'Quanto dura una seduta di igiene?',
      answer: 'Una seduta di igiene orale completa dura circa 45-60 minuti, includendo la rimozione di placca e tartaro, lucidatura e consigli personalizzati.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Igiene orale Morbegno | Pulizia denti | Studio Romegialli</title>
        <meta name="description" content="Igiene orale professionale a Morbegno. Pulizia denti, detartrasi, prevenzione. Prenota la tua seduta di igiene dentale." />
        <link rel="canonical" href="https://studioromegialli.it/servizi/igiene-orale" />
      </Helmet>

      <Header />

      <main className="pt-20">
        <article className="py-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <Button asChild variant="ghost" className="mb-8">
              <Link to="/servizi">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Torna ai servizi
              </Link>
            </Button>

            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance" style={{letterSpacing: '-0.02em'}}>
              Igiene orale professionale a Morbegno
            </h1>

            <div className="prose prose-lg max-w-none">
              <p className="text-xl text-muted-foreground leading-relaxed mb-8">
                L'igiene orale professionale è il fondamento della prevenzione dentale. Una pulizia regolare mantiene denti e gengive sani, prevenendo carie, gengiviti e parodontite.
              </p>

              <h2 className="text-2xl font-bold mt-12 mb-4">Cos'è l'igiene orale professionale</h2>
              <p className="text-muted-foreground leading-relaxed">
                L'igiene orale professionale, o detartrasi, è un trattamento che rimuove placca batterica e tartaro dai denti e dalle gengive. Anche con una corretta igiene domiciliare, alcune zone rimangono difficili da pulire e il tartaro si accumula nel tempo.
              </p>

              <h2 className="text-2xl font-bold mt-12 mb-4">Benefici della pulizia professionale</h2>
              <ul className="space-y-2 text-muted-foreground">
                <li>Prevenzione di carie e malattie gengivali</li>
                <li>Rimozione di macchie superficiali</li>
                <li>Alito più fresco</li>
                <li>Gengive più sane e meno sanguinamento</li>
                <li>Individuazione precoce di problemi dentali</li>
              </ul>

              <h2 className="text-2xl font-bold mt-12 mb-4">Quando è consigliata</h2>
              <p className="text-muted-foreground leading-relaxed">
                L'igiene orale professionale è consigliata ogni 6 mesi per la maggior parte delle persone. Tuttavia, in presenza di parodontite, predisposizione al tartaro o altre condizioni specifiche, il dentista può consigliare sedute più frequenti (ogni 3-4 mesi).
              </p>

              <h2 className="text-2xl font-bold mt-12 mb-4">Il percorso di trattamento</h2>
              <ol className="space-y-3 text-muted-foreground">
                <li><strong>Valutazione iniziale:</strong> L'igienista esamina lo stato di denti e gengive.</li>
                <li><strong>Rimozione del tartaro:</strong> Con strumenti ultrasonici e manuali, si rimuove il tartaro sopra e sotto il margine gengivale.</li>
                <li><strong>Lucidatura:</strong> I denti vengono lucidati per rimuovere macchie superficiali e rendere la superficie più liscia.</li>
                <li><strong>Consigli personalizzati:</strong> L'igienista fornisce indicazioni su tecniche di spazzolamento, uso del filo interdentale e altri strumenti.</li>
              </ol>

              <h2 className="text-2xl font-bold mt-12 mb-4">Perché scegliere Studio Romegialli</h2>
              <p className="text-muted-foreground leading-relaxed">
                Il nostro team di igienisti dentali è altamente qualificato e utilizza strumenti moderni per garantire un trattamento efficace e confortevole. Dedichiamo tempo ad ascoltare le tue esigenze e a fornirti consigli personalizzati per mantenere una perfetta igiene orale a casa.
              </p>
            </div>

            <div className="mt-16">
              <h2 className="text-3xl font-bold mb-8">Domande frequenti</h2>
              <FaqAccordion faqs={faqs} />
            </div>
          </div>
        </article>

        <CtaSection
          title="Prenota la tua seduta di igiene orale"
          description="Mantieni denti e gengive sani con una pulizia professionale regolare."
        />
      </main>

      <Footer />
    </>
  );
};

export default IgieneOralePage;