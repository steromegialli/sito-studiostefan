import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import BlogList from '@/components/BlogList';
import { blogData } from '@/constants/blogData';

const BlogPage = () => {
  return (
    <>
      <Helmet>
        <title>Blog | Studio Romegialli | Consigli dentali Morbegno</title>
        <meta name="description" content="Blog dello Studio Romegialli: consigli, guide e informazioni su salute orale, prevenzione, trattamenti dentali." />
        <link rel="canonical" href="https://studioromegialli.it/blog" />
      </Helmet>

      <Header />

      <main className="pt-20">
        <section className="py-24 bg-gradient-to-b from-muted to-background">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance" style={{letterSpacing: '-0.02em'}}>
              Blog
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Consigli, guide e informazioni per prenderti cura del tuo sorriso.
            </p>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <BlogList articles={blogData} />
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default BlogPage;