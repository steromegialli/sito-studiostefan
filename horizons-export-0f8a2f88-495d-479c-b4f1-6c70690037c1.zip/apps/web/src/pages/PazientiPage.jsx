import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import CtaSection from '@/components/CtaSection';

const PazientiPage = () => {
  return (
    <>
      <Helmet>
        <title>Per i pazienti | Studio Romegialli | Dentista Morbegno</title>
        <meta name="description" content="Informazioni per i pazienti dello Studio Romegialli: paura del dentista, cure per adulti, famiglie, bambini, prevenzione." />
        <link rel="canonical" href="https://studioromegialli.it/pazienti" />
      </Helmet>

      <Header />

      <main className="pt-20">
        <section className="py-24 bg-gradient-to-b from-muted to-background">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance" style={{letterSpacing: '-0.02em'}}>
              Informazioni per i pazienti
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Tutto quello che devi sapere per sentirti a tuo agio e preparato.
            </p>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
            <div>
              <h2 className="text-3xl font-bold mb-6">Hai paura del dentista?</h2>
              <p className="text-lg text-muted-foreground leading-relaxed mb-4">
                La paura del dentista è molto comune e la comprendiamo. Il nostro approccio è empatico e rassicurante. Spieghiamo ogni passaggio prima di procedere e lavoriamo con delicatezza.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Per i casi più complessi, possiamo valutare tecniche di sedazione cosciente che ti permettono di affrontare il trattamento in modo sereno.
              </p>
            </div>

            <div>
              <h2 className="text-3xl font-bold mb-6">Cure per adulti</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Offriamo tutti i trattamenti odontoiatrici per adulti: dalla semplice otturazione all'implantologia, dall'ortodonzia invisibile all'estetica dentale. Ogni piano di cura è personalizzato sulle tue esigenze.
              </p>
            </div>

            <div>
              <h2 className="text-3xl font-bold mb-6">Cure per famiglie</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Seguiamo intere famiglie, dai bambini agli anziani. Possiamo organizzare appuntamenti consecutivi per maggiore comodità e offriamo un ambiente accogliente per tutti.
              </p>
            </div>

            <div>
              <h2 className="text-3xl font-bold mb-6">Cure per bambini</h2>
              <p className="text-lg text-muted-foreground leading-relaxed mb-4">
                I bambini meritano un'attenzione speciale. Il nostro approccio è delicato e giocoso, per far vivere la visita dal dentista come un'esperienza positiva.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Educhiamo i piccoli pazienti all'igiene orale e alla prevenzione, creando le basi per una salute dentale duratura.
              </p>
            </div>

            <div>
              <h2 className="text-3xl font-bold mb-6">Prevenzione nel tempo</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                La prevenzione è la chiave per mantenere denti e gengive sani. Controlli regolari, igiene professionale e buone abitudini quotidiane fanno la differenza.
              </p>
            </div>
          </div>
        </section>

        <CtaSection />
      </main>

      <Footer />
    </>
  );
};

export default PazientiPage;