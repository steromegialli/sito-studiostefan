import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Shield, Zap, Heart, Award, Stethoscope, Activity, Sparkles, Layers, CheckCircle2, Phone } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HeroSection from '@/components/HeroSection';
import AnimatedServiceGrid from '@/components/AnimatedServiceGrid';
import AnimatedTimeline from '@/components/AnimatedTimeline';
import ImageSlider from '@/components/ImageSlider';
import InteractiveContactForm from '@/components/InteractiveContactForm';

const HomePage = () => {
  const services = [
    {
      title: "Implantologia Avanzata",
      desc: "Soluzioni fisse con tecnologie 3D per risultati perfetti e duraturi.",
      icon: Layers,
      colSpan: "md:col-span-2",
      rowSpan: "md:row-span-2",
      link: "/servizi",
      image: "https://images.unsplash.com/photo-1606811841689-23dfddce3e95"
    },
    {
      title: "Estetica Dentale",
      desc: "Faccette e sbiancamento laser per un sorriso luminoso.",
      icon: Sparkles,
      colSpan: "md:col-span-1",
      rowSpan: "md:row-span-1",
      link: "/servizi"
    },
    {
      title: "Ortodonzia Invisibile",
      desc: "Allineatori trasparenti su misura.",
      icon: Activity,
      colSpan: "md:col-span-1",
      rowSpan: "md:row-span-1",
      link: "/servizi"
    },
    {
      title: "Prevenzione & Igiene",
      desc: "Protocolli avanzati per la salute gengivale.",
      icon: Shield,
      colSpan: "md:col-span-2",
      rowSpan: "md:row-span-1",
      link: "/servizi"
    }
  ];

  const timelineSteps = [
    {
      title: "Prima Visita & Consulenza",
      description: "Ascoltiamo le tue esigenze e valutiamo lo stato di salute della tua bocca con tecnologie diagnostiche avanzate.",
      icon: Stethoscope
    },
    {
      title: "Diagnosi 3D",
      description: "Utilizziamo scanner intraorali e radiologia digitale per una visione completa e precisa senza fastidi.",
      icon: Activity
    },
    {
      title: "Pianificazione Digitale",
      description: "Progettiamo il tuo nuovo sorriso al computer, mostrandoti il risultato finale prima ancora di iniziare.",
      icon: Zap
    },
    {
      title: "Trattamento Minimamente Invasivo",
      description: "Eseguiamo le cure con tecniche moderne che riducono i tempi alla poltrona e garantiscono il massimo comfort.",
      icon: Heart
    },
    {
      title: "Follow-up & Mantenimento",
      description: "Ti seguiamo nel tempo con richiami periodici per mantenere i risultati ottenuti perfetti negli anni.",
      icon: Shield
    }
  ];

  const sliderImages = [
    {
      image: "https://images.unsplash.com/photo-1629909615957-be38d48fbbe6",
      title: "Ambienti Confortevoli",
      subtitle: "Spazi progettati per il tuo relax"
    },
    {
      image: "https://images.unsplash.com/photo-1677276048965-817179b48fc7",
      title: "Tecnologia All'avanguardia",
      subtitle: "Strumentazione di ultima generazione"
    }
  ];

  return (
    <div className="bg-background min-h-screen text-foreground selection:bg-primary/30">
      <Helmet>
        <title>Studio Romegialli | Eccellenza Odontoiatrica a Morbegno</title>
        <meta name="description" content="Studio dentistico all'avanguardia a Morbegno. Tecnologie 3D, implantologia e ortodonzia invisibile." />
      </Helmet>

      <Header />

      <main>
        {/* 1. HERO SECTION */}
        <HeroSection 
          title="Studio Romegialli Eccellenza Odontoiatrica"
          subtitle="Tecnologia avanzata e cura personalizzata per il tuo sorriso perfetto."
          videoUrl="https://images.unsplash.com/photo-1629909613638-0e4a1fad8f81"
          buttons={[
            { text: "Prenota Visita", link: "/contatti", primary: true },
            { text: "Scopri di Più", link: "/chi-siamo", primary: false }
          ]}
        />

        {/* 2. PUNTI DI FORZA */}
        <section className="py-24 relative z-10 -mt-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { icon: Zap, title: "Tecnologia", desc: "Strumenti digitali 3D" },
                { icon: Award, title: "Esperienza", desc: "Oltre 20 anni di successi" },
                { icon: Heart, title: "Cura", desc: "Approccio empatico" },
                { icon: Shield, title: "Risultati", desc: "Garanzia nel tempo" }
              ].map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  whileHover={{ y: -10 }}
                  className="glass-effect p-8 rounded-3xl text-center group"
                >
                  <div className="w-16 h-16 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary transition-colors duration-300">
                    <item.icon className="w-8 h-8 text-primary group-hover:text-white transition-colors" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                  <p className="text-muted-foreground">{item.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* 3. PRESENTAZIONE */}
        <section className="py-24 relative overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img 
              src="https://images.unsplash.com/photo-1694678459294-da579f249296" 
              alt="Studio" 
              className="w-full h-full object-cover opacity-20"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-background via-background/90 to-transparent" />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl">
              <motion.h2 
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="text-4xl md:text-5xl font-bold mb-6 text-white"
              >
                Il futuro dell'odontoiatria, <span className="text-gradient">oggi.</span>
              </motion.h2>
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="text-xl text-muted-foreground leading-relaxed mb-8"
              >
                Abbiamo rivoluzionato l'esperienza dal dentista. Dimentica il dolore e l'ansia: nel nostro studio troverai un ambiente rilassante e tecnologie che rendono ogni trattamento rapido, preciso e confortevole.
              </motion.p>
              <motion.ul 
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4 }}
                className="space-y-4 mb-10"
              >
                {['Impronte digitali senza fastidi', 'Interventi minimamente invasivi', 'Materiali biocompatibili di altissima qualità'].map((item, i) => (
                  <li key={i} className="flex items-center text-white/90">
                    <CheckCircle2 className="w-6 h-6 text-accent mr-3" />
                    {item}
                  </li>
                ))}
              </motion.ul>
            </div>
          </div>
        </section>

        {/* 4. SERVIZI */}
        <section className="py-24 bg-card/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16 text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">I Nostri Servizi</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Soluzioni complete per la salute e la bellezza del tuo sorriso.
            </p>
          </div>
          <AnimatedServiceGrid services={services} />
        </section>

        {/* 5. TIMELINE */}
        <section className="py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16 text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">Il Tuo Percorso</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Un approccio strutturato per garantirti i migliori risultati.
            </p>
          </div>
          <AnimatedTimeline steps={timelineSteps} />
        </section>

        {/* 7. SLIDER IMMAGINI */}
        <section className="py-24 bg-card/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ImageSlider slides={sliderImages} />
          </div>
        </section>

        {/* 8. FIDUCIA / STATS */}
        <section className="py-24 relative overflow-hidden">
          <div className="absolute inset-0 bg-primary/5 skew-y-3 transform origin-top-left -z-10" />
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { number: "5000+", label: "Pazienti Soddisfatti" },
                { number: "20+", label: "Anni di Esperienza" },
                { number: "15k+", label: "Trattamenti Completati" }
              ].map((stat, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.2 }}
                  className="glass-effect p-10 rounded-3xl text-center"
                >
                  <div className="text-5xl md:text-6xl font-extrabold text-gradient mb-4">{stat.number}</div>
                  <div className="text-xl text-white font-medium">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* 11. CTA FINALE & FORM */}
        <section className="py-24 relative">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <div>
                <h2 className="text-4xl md:text-6xl font-bold mb-6 text-white">
                  Pronto a sorridere di nuovo?
                </h2>
                <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
                  Prenota una prima visita senza impegno. Il nostro team è pronto ad accoglierti e a studiare la soluzione migliore per te.
                </p>
                <div className="space-y-6">
                  <div className="flex items-center glass-effect p-4 rounded-2xl">
                    <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mr-4">
                      <Phone className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Chiamaci subito</div>
                      <div className="text-xl font-bold text-white">0342 612345</div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <InteractiveContactForm />
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default HomePage;