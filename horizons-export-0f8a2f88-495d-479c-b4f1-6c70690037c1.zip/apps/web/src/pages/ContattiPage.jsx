import React from 'react';
import { Helmet } from 'react-helmet';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ContactForm from '@/components/ContactForm';
import FaqAccordion from '@/components/FaqAccordion';
import { Card, CardContent } from '@/components/ui/card';

const ContattiPage = () => {
  const contactFaqs = [
    {
      question: 'Come posso prenotare una visita?',
      answer: 'Puoi prenotare chiamando il numero 0342 612345, inviando un\'email a info@studioromegialli.it, oppure compilando il modulo di contatto su questa pagina.'
    },
    {
      question: 'Quanto tempo prima devo prenotare?',
      answer: 'Ti consigliamo di prenotare con almeno una settimana di anticipo. Per le urgenze, cerchiamo sempre di trovare spazio il prima possibile.'
    },
    {
      question: 'Cosa devo portare alla prima visita?',
      answer: 'Porta con te eventuali radiografie precedenti, una lista di farmaci che assumi e la tessera sanitaria. Se hai particolari ansie o domande, annotale per discuterne durante la visita.'
    },
    {
      question: 'Accettate pagamenti con carta?',
      answer: 'Sì, accettiamo pagamenti con carte di credito, bancomat e contanti. Offriamo anche possibilità di rateizzazione per trattamenti più complessi.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Contatti | Studio Romegialli | Dentista Morbegno</title>
        <meta name="description" content="Contatta Studio Romegialli a Morbegno. Telefono, email, indirizzo, orari. Prenota la tua visita dentistica." />
        <link rel="canonical" href="https://studioromegialli.it/contatti" />
      </Helmet>

      <Header />

      <main className="pt-20">
        <section className="py-24 bg-gradient-to-b from-muted to-background">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance" style={{letterSpacing: '-0.02em'}}>
              Contatta Studio Romegialli a Morbegno
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Siamo qui per rispondere alle tue domande e fissare un appuntamento.
            </p>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
              <div>
                <h2 className="text-2xl font-bold mb-8">I nostri contatti</h2>
                
                <div className="space-y-6 mb-12">
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <MapPin className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                        <div>
                          <h3 className="font-semibold mb-1">Indirizzo</h3>
                          <p className="text-muted-foreground">
                            Via Roma 15<br />
                            23017 Morbegno (SO)
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <Phone className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                        <div>
                          <h3 className="font-semibold mb-1">Telefono</h3>
                          <a href="tel:+390342612345" className="text-muted-foreground hover:text-primary transition-colors duration-200">
                            0342 612345
                          </a>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <Mail className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                        <div>
                          <h3 className="font-semibold mb-1">Email</h3>
                          <a href="mailto:info@studioromegialli.it" className="text-muted-foreground hover:text-primary transition-colors duration-200">
                            info@studioromegialli.it
                          </a>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <Clock className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                        <div>
                          <h3 className="font-semibold mb-1">Orari</h3>
                          <div className="text-muted-foreground">
                            <p>Lunedì - Venerdì: 9:00 - 19:00</p>
                            <p>Sabato: 9:00 - 13:00</p>
                            <p>Domenica: Chiuso</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="bg-muted rounded-2xl p-6">
                  <h3 className="font-semibold mb-4">Come raggiungerci</h3>
                  <div className="space-y-3 text-sm text-muted-foreground">
                    <p>
                      <strong>In auto:</strong> Lo studio si trova nel centro di Morbegno. Parcheggi pubblici disponibili nelle vicinanze.
                    </p>
                    <p>
                      <strong>Con i mezzi pubblici:</strong> Autobus di linea fermano in centro. La stazione ferroviaria di Morbegno dista circa 10 minuti a piedi.
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h2 className="text-2xl font-bold mb-8">Inviaci un messaggio</h2>
                <ContactForm />
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-muted">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="aspect-video rounded-2xl overflow-hidden shadow-xl bg-slate-200">
              <iframe
                src="https://www.openstreetmap.org/export/embed.html?bbox=9.5567%2C46.1267%2C9.5767%2C46.1467&layer=mapnik&marker=46.1367%2C9.5667"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                title="Mappa Studio Romegialli Morbegno"
              />
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold mb-8 text-center">Domande frequenti sui contatti</h2>
            <FaqAccordion faqs={contactFaqs} />
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default ContattiPage;