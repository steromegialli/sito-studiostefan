import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ServiceCard from '@/components/ServiceCard';
import CtaSection from '@/components/CtaSection';
import { servicesData } from '@/constants/serviceData';

const ServiziPage = () => {
  return (
    <>
      <Helmet>
        <title>Servizi dentistici Morbegno | Studio Romegialli</title>
        <meta name="description" content="Servizi odontoiatrici completi a Morbegno: igiene, sbiancamento, implantologia, ortodonzia, estetica dentale. Tecnologie moderne e cura personalizzata." />
        <link rel="canonical" href="https://studioromegialli.it/servizi" />
      </Helmet>

      <Header />

      <main className="pt-20">
        <section className="py-24 bg-gradient-to-b from-muted to-background">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance" style={{letterSpacing: '-0.02em'}}>
              Servizi dentistici a Morbegno
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed max-w-2xl mx-auto">
              Offriamo una gamma completa di trattamenti odontoiatrici per tutta la famiglia, con tecnologie moderne e approccio personalizzato.
            </p>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {servicesData.map((service, index) => (
                <ServiceCard key={service.id} service={service} index={index} />
              ))}
            </div>
          </div>
        </section>

        <CtaSection
          title="Non trovi il servizio che cerchi?"
          description="Contattaci per parlare delle tue esigenze. Saremo felici di aiutarti."
        />
      </main>

      <Footer />
    </>
  );
};

export default ServiziPage;