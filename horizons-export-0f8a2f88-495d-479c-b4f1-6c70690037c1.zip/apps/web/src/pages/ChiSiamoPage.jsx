import React from 'react';
import { Helmet } from 'react-helmet';
import { Heart, Award, Users, Shield, Lightbulb, Clock, CheckCircle2, Smile } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import TeamMemberCard from '@/components/TeamMemberCard';
import CtaSection from '@/components/CtaSection';

const ChiSiamoPage = () => {
  const team = [
    {
      name: 'Dr. Paolo Romegialli',
      role: 'Odontoiatra',
      initials: 'PR',
      bio: 'Specializzato in implantologia e protesi. Oltre 25 anni di esperienza al servizio del sorriso dei pazienti.',
      image: ''
    },
    {
      name: 'Dr.ssa Chiara Bianchi',
      role: 'Igienista dentale',
      initials: 'CB',
      bio: 'Esperta in prevenzione e igiene orale. Approccio delicato e personalizzato per ogni paziente.',
      image: ''
    },
    {
      name: 'Marta Colombo',
      role: 'Assistente alla poltrona',
      initials: 'MC',
      bio: 'Supporto tecnico e umano durante i trattamenti. Sempre attenta al comfort del paziente.',
      image: ''
    },
    {
      name: 'Elena Rossi',
      role: 'Segretaria',
      initials: 'ER',
      bio: 'Primo punto di contatto con lo studio. Gestisce appuntamenti e accoglienza con professionalità.',
      image: ''
    }
  ];

  const values = [
    {
      icon: Heart,
      title: 'Ascolto',
      description: 'Dedichiamo tempo ad ascoltare le tue esigenze e preoccupazioni.'
    },
    {
      icon: Award,
      title: 'Precisione',
      description: 'Ogni trattamento è eseguito con la massima cura e attenzione ai dettagli.'
    },
    {
      icon: Shield,
      title: 'Trasparenza',
      description: 'Preventivi chiari e spiegazioni complete prima di ogni intervento.'
    },
    {
      icon: CheckCircle2,
      title: 'Prevenzione',
      description: 'Crediamo nell\'importanza della prevenzione per evitare problemi futuri.'
    },
    {
      icon: Lightbulb,
      title: 'Aggiornamento',
      description: 'Formazione continua per offrire le tecniche più moderne ed efficaci.'
    },
    {
      icon: Smile,
      title: 'Comfort',
      description: 'Ambiente accogliente e tecniche per ridurre al minimo il disagio.'
    },
    {
      icon: Clock,
      title: 'Rispetto dei tempi',
      description: 'Puntuali negli appuntamenti e nei tempi di trattamento concordati.'
    },
    {
      icon: Users,
      title: 'Cura personalizzata',
      description: 'Ogni paziente riceve un piano di cura su misura per le sue esigenze.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Chi siamo | Studio Romegialli | Dentista Morbegno</title>
        <meta name="description" content="Scopri lo Studio Romegialli a Morbegno: team, filosofia, valori. Odontoiatria moderna con attenzione alla persona dal 2003." />
        <link rel="canonical" href="https://studioromegialli.it/chi-siamo" />
      </Helmet>

      <Header />

      <main className="pt-20">
        <section className="py-24 bg-gradient-to-b from-muted to-background">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance" style={{letterSpacing: '-0.02em'}}>
              Studio Romegialli: odontoiatria a Morbegno con attenzione alla persona
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Da oltre vent'anni al servizio della salute orale in Valtellina.
            </p>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="prose prose-lg max-w-none">
              <p className="text-lg leading-relaxed text-muted-foreground">
                Lo Studio Romegialli nasce nel 2003 a Morbegno con l'obiettivo di offrire cure odontoiatriche di qualità in un ambiente accogliente e rassicurante. Nel corso degli anni, abbiamo costruito un rapporto di fiducia con centinaia di famiglie della Valtellina e della provincia di Sondrio.
              </p>
              <p className="text-lg leading-relaxed text-muted-foreground mt-6">
                La nostra missione è prenderci cura del tuo sorriso con professionalità, empatia e tecnologie moderne. Crediamo che ogni paziente sia unico e meriti un'attenzione personalizzata, dalla prima visita al mantenimento dei risultati nel tempo.
              </p>
            </div>
          </div>
        </section>

        <section className="py-20 bg-muted">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance" style={{letterSpacing: '-0.02em'}}>
                La nostra filosofia
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                Valori che guidano il nostro lavoro ogni giorno.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {values.map((value, index) => (
                <div key={index} className="text-center">
                  <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <value.icon className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{value.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {value.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance" style={{letterSpacing: '-0.02em'}}>
                Il nostro team
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                Professionisti qualificati e appassionati, pronti ad accoglierti.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {team.map((member, index) => (
                <TeamMemberCard key={index} member={member} />
              ))}
            </div>
          </div>
        </section>

        <CtaSection
          title="Vieni a conoscerci"
          description="Prenota una prima visita per scoprire come possiamo prenderci cura del tuo sorriso."
        />
      </main>

      <Footer />
    </>
  );
};

export default ChiSiamoPage;