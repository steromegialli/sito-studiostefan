import React from 'react';
import { Helmet } from 'react-helmet';
import { CheckCircle2 } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import CtaSection from '@/components/CtaSection';

const PrimaVisitaPage = () => {
  return (
    <>
      <Helmet>
        <title>Prima visita dentistica Morbegno | Studio Romegialli</title>
        <meta name="description" content="Prima visita odontoiatrica a Morbegno. Scopri cosa aspettarti: accoglienza, valutazione, piano di cura personalizzato." />
        <link rel="canonical" href="https://studioromegialli.it/prima-visita" />
      </Helmet>

      <Header />

      <main className="pt-20">
        <section className="py-24 bg-gradient-to-b from-muted to-background">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance" style={{letterSpacing: '-0.02em'}}>
              Prima visita dentistica a Morbegno
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Un momento importante per conoscerci e iniziare il percorso verso un sorriso sano.
            </p>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="prose prose-lg max-w-none">
              <h2 className="text-3xl font-bold mb-6">Cosa aspettarsi dalla prima visita</h2>
              <p className="text-lg text-muted-foreground leading-relaxed mb-8">
                La prima visita è un momento fondamentale per conoscerci, capire le tue esigenze e valutare lo stato di salute della tua bocca. Dedichiamo tutto il tempo necessario per ascoltarti e fornirti informazioni chiare.
              </p>

              <div className="space-y-8 mt-12">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                      <CheckCircle2 className="w-6 h-6 text-primary" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Accoglienza calorosa</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Ti accogliamo in un ambiente confortevole e rassicurante. La nostra segretaria ti guiderà nella compilazione della scheda anamnestica, dove potrai indicare eventuali allergie, farmaci assunti e problematiche specifiche.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                      <CheckCircle2 className="w-6 h-6 text-primary" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Ascolto delle tue esigenze</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Il dentista dedica tempo ad ascoltare le tue preoccupazioni, i tuoi obiettivi e le tue aspettative. Ogni paziente è unico e vogliamo capire cosa è importante per te.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                      <CheckCircle2 className="w-6 h-6 text-primary" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Valutazione clinica completa</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Eseguiamo un esame accurato di denti, gengive, mucose e occlusione. Valutiamo la presenza di carie, problemi gengivali, usura dentale e altre condizioni che richiedono attenzione.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                      <CheckCircle2 className="w-6 h-6 text-primary" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Esami diagnostici</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Se necessario, eseguiamo radiografie digitali per una diagnosi più precisa. Le immagini ci permettono di individuare problemi non visibili a occhio nudo, come carie tra i denti o problemi alle radici.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                      <CheckCircle2 className="w-6 h-6 text-primary" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Spiegazione del piano di cura</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Ti spieghiamo in modo chiaro e comprensibile la situazione attuale e le opzioni di trattamento disponibili. Discutiamo insieme priorità, tempistiche e alternative.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                      <CheckCircle2 className="w-6 h-6 text-primary" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Preventivo trasparente</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Forniamo un preventivo dettagliato e scritto, senza sorprese. Ogni voce è spiegata chiaramente e sei libero di fare domande o richiedere chiarimenti.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                      <CheckCircle2 className="w-6 h-6 text-primary" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Spazio per domande</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Alla fine della visita, hai tutto il tempo per fare domande e chiarire dubbi. Vogliamo che tu esca dallo studio con le idee chiare e sereno.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <CtaSection
          title="Prenota la tua prima visita"
          description="Inizia il percorso verso un sorriso sano. Ti aspettiamo a Morbegno."
        />
      </main>

      <Footer />
    </>
  );
};

export default PrimaVisitaPage;