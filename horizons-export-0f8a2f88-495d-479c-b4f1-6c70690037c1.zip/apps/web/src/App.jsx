import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/HomePage';
import ChiSiamoPage from './pages/ChiSiamoPage';
import ServiziPage from './pages/ServiziPage';
import ContattiPage from './pages/ContattiPage';

function App() {
  return (
    <Router>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/chi-siamo" element={<ChiSiamoPage />} />
        <Route path="/servizi" element={<ServiziPage />} />
        <Route path="/contatti" element={<ContattiPage />} />
        
        <Route path="*" element={
          <div className="min-h-screen flex items-center justify-center bg-background text-foreground">
            <div className="text-center">
              <h1 className="text-6xl font-bold mb-4 text-primary">404</h1>
              <p className="text-muted-foreground mb-8 text-xl">Pagina non trovata.</p>
              <a href="/" className="text-white hover:text-primary transition-colors">Torna alla Home</a>
            </div>
          </div>
        } />
      </Routes>
    </Router>
  );
}

export default App;