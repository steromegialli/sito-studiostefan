export const generateLocalBusinessSchema = () => {
  return {
    '@context': 'https://schema.org',
    '@type': 'Dentist',
    name: 'Studio Romegialli',
    image: 'https://images.unsplash.com/photo-1629909615957-be38d48fbbe6',
    '@id': 'https://studioromegialli.it',
    url: 'https://studioromegialli.it',
    telephone: '+39 0342 612345',
    email: 'info@studioromegialli.it',
    address: {
      '@type': 'PostalAddress',
      streetAddress: 'Via Roma 15',
      addressLocality: 'Morbegno',
      addressRegion: 'SO',
      postalCode: '23017',
      addressCountry: 'IT'
    },
    geo: {
      '@type': 'GeoCoordinates',
      latitude: 46.1367,
      longitude: 9.5667
    },
    openingHoursSpecification: [
      {
        '@type': 'OpeningHoursSpecification',
        dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
        opens: '09:00',
        closes: '19:00'
      },
      {
        '@type': 'OpeningHoursSpecification',
        dayOfWeek: 'Saturday',
        opens: '09:00',
        closes: '13:00'
      }
    ],
    priceRange: '€€',
    areaServed: {
      '@type': 'City',
      name: 'Morbegno'
    }
  };
};

export const generateFAQSchema = (faqs) => {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map(faq => ({
      '@type': 'Question',
      name: faq.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.answer
      }
    }))
  };
};

export const generateArticleSchema = (article) => {
  return {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: article.title,
    description: article.metaDescription,
    image: 'https://images.unsplash.com/photo-1629909615957-be38d48fbbe6',
    datePublished: article.date,
    dateModified: article.date,
    author: {
      '@type': 'Organization',
      name: 'Studio Romegialli'
    },
    publisher: {
      '@type': 'Organization',
      name: 'Studio Romegialli',
      logo: {
        '@type': 'ImageObject',
        url: 'https://studioromegialli.it/logo.png'
      }
    }
  };
};

export const generateBreadcrumbSchema = (items) => {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.name,
      item: item.url
    }))
  };
};