export const faqData = [
  {
    question: 'Ogni quanto tempo devo fare una visita di controllo?',
    answer: 'Si consiglia una visita di controllo ogni 6 mesi per mantenere una buona salute orale e prevenire problemi. In alcuni casi, il dentista può consigliare controlli più frequenti.'
  },
  {
    question: 'Lo sbiancamento dentale rovina i denti?',
    answer: 'No, lo sbiancamento professionale eseguito dal dentista è sicuro e non danneggia lo smalto. Utilizziamo prodotti certificati e tecniche che rispettano la salute dei tuoi denti.'
  },
  {
    question: 'Gli impianti dentali sono dolorosi?',
    answer: 'L\'intervento viene eseguito in anestesia locale, quindi non si avverte dolore durante la procedura. Nel post-operatorio, eventuali fastidi sono gestibili con comuni antidolorifici.'
  },
  {
    question: 'Quanto dura un impianto dentale?',
    answer: 'Con una corretta igiene orale e controlli regolari, un impianto dentale può durare molti anni, spesso per tutta la vita. La durata dipende anche dalla qualità dell\'osso e dalle abitudini del paziente.'
  },
  {
    question: 'La devitalizzazione fa male?',
    answer: 'La devitalizzazione viene eseguita in anestesia locale, quindi non si avverte dolore durante il trattamento. Dopo l\'intervento, possono esserci lievi fastidi che si risolvono in pochi giorni.'
  },
  {
    question: 'A che età portare il bambino dal dentista?',
    answer: 'Si consiglia la prima visita intorno ai 3-4 anni, quando tutti i denti da latte sono presenti. È importante abituare il bambino fin da piccolo all\'ambiente odontoiatrico.'
  },
  {
    question: 'Come posso prenotare una visita?',
    answer: 'Puoi prenotare chiamando il numero 0342 612345, inviando un\'email a info@studioromegialli.it, oppure compilando il modulo di contatto sul nostro sito.'
  },
  {
    question: 'Dove si trova lo studio?',
    answer: 'Lo Studio Romegialli si trova a Morbegno, in Via Roma 15, in provincia di Sondrio, facilmente raggiungibile dalla Valtellina e dalle zone limitrofe.'
  },
  {
    question: 'Quali servizi offrite?',
    answer: 'Offriamo tutti i servizi odontoiatrici: igiene orale, sbiancamento, implantologia, protesi, ortodonzia, ortodonzia invisibile, estetica dentale, endodonzia, conservativa, parodontologia e pedodonzia.'
  },
  {
    question: 'Fate preventivi gratuiti?',
    answer: 'Sì, durante la prima visita valutiamo la situazione e forniamo un preventivo dettagliato e trasparente, senza impegno.'
  },
  {
    question: 'Ho paura del dentista, cosa posso fare?',
    answer: 'Comprendiamo l\'ansia dentale. Il nostro approccio è empatico e rassicurante. Spieghiamo ogni passaggio e lavoriamo con delicatezza. Possiamo anche valutare tecniche di sedazione cosciente per i casi più complessi.'
  },
  {
    question: 'Cosa fare in caso di mal di denti improvviso?',
    answer: 'Contattaci subito. Cerchiamo sempre di trovare spazio per le urgenze. Nel frattempo, puoi assumere un antidolorifico e applicare ghiaccio esternamente sulla guancia.'
  },
  {
    question: 'Perché le gengive sanguinano quando spazzolo i denti?',
    answer: 'Il sanguinamento gengivale è spesso segno di infiammazione (gengivite) causata da accumulo di placca. È importante fare una visita per valutare la situazione e intervenire con igiene professionale e corrette tecniche di spazzolamento.'
  },
  {
    question: 'Cosa fare se manca un dente?',
    answer: 'Un dente mancante può essere sostituito con un impianto dentale, una protesi fissa (ponte) o una protesi mobile. Durante la visita valutiamo la soluzione migliore per il tuo caso.'
  },
  {
    question: 'L\'ortodonzia invisibile funziona davvero?',
    answer: 'Sì, gli allineatori trasparenti sono efficaci per correggere molti problemi di allineamento. Sono discreti, rimovibili e confortevoli. Valutiamo insieme se sono adatti al tuo caso.'
  },
  {
    question: 'Posso mettere l\'apparecchio da adulto?',
    answer: 'Assolutamente sì. L\'ortodonzia non ha limiti di età. Molti adulti scelgono trattamenti ortodontici, spesso con allineatori invisibili per maggiore discrezione.'
  },
  {
    question: 'Quanto dura lo sbiancamento dentale?',
    answer: 'I risultati dello sbiancamento professionale possono durare da 1 a 3 anni, a seconda delle abitudini alimentari e dell\'igiene orale. Evitare fumo, caffè e vino rosso aiuta a mantenere i risultati più a lungo.'
  },
  {
    question: 'Quanto dura una seduta di igiene orale?',
    answer: 'Una seduta di igiene orale professionale dura circa 45-60 minuti. Include la rimozione di placca e tartaro, lucidatura e consigli personalizzati per l\'igiene domiciliare.'
  },
  {
    question: 'Perché è importante la prevenzione?',
    answer: 'La prevenzione permette di individuare problemi in fase iniziale, quando sono più facili e meno costosi da trattare. Controlli regolari e igiene professionale mantengono denti e gengive sani nel tempo.'
  },
  {
    question: 'Cosa devo fare prima della visita?',
    answer: 'Porta con te eventuali radiografie precedenti e una lista di farmaci che assumi. Se hai particolari ansie o domande, annotale per discuterne durante la visita.'
  },
  {
    question: 'Come scelgo il trattamento giusto?',
    answer: 'Durante la visita ti spieghiamo tutte le opzioni disponibili, con vantaggi, svantaggi e costi. La scelta finale è sempre tua, guidata dalle nostre indicazioni professionali.'
  },
  {
    question: 'Posso prenotare per tutta la famiglia?',
    answer: 'Sì, seguiamo pazienti di tutte le età. Possiamo organizzare appuntamenti consecutivi per i membri della famiglia per maggiore comodità.'
  },
  {
    question: 'C\'è parcheggio vicino allo studio?',
    answer: 'Sì, nelle vicinanze dello studio sono disponibili parcheggi pubblici gratuiti e a pagamento.'
  },
  {
    question: 'Come arrivo allo studio con i mezzi pubblici?',
    answer: 'Lo studio è raggiungibile con autobus di linea che fermano in centro a Morbegno. La stazione ferroviaria di Morbegno dista circa 10 minuti a piedi.'
  },
  {
    question: 'Accettate carte di credito?',
    answer: 'Sì, accettiamo pagamenti con carte di credito, bancomat e contanti. Offriamo anche possibilità di rateizzazione per trattamenti più complessi.'
  }
];