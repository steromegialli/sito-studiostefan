export const blogData = [
  {
    id: 1,
    slug: 'come-scegliere-dentista-morbegno',
    title: 'Come scegliere un dentista a Morbegno',
    metaTitle: 'Come scegliere dentista a Morbegno | Studio Romegialli',
    metaDescription: 'Guida per scegliere il miglior dentista a Morbegno. Criteri, qualifiche, esperienza e fiducia. Scopri Studio Romegialli.',
    date: '2026-04-15',
    excerpt: 'Scegliere il dentista giusto è una decisione importante per la tua salute orale. Ecco i criteri da considerare quando cerchi un professionista a Morbegno.',
    category: 'Consigli'
  },
  {
    id: 2,
    slug: 'ogni-quanto-pulizia-denti',
    title: 'Ogni quanto fare la pulizia dei denti?',
    metaTitle: 'Pulizia denti: ogni quanto farla? | Studio Romegialli',
    metaDescription: 'Frequenza consigliata per la pulizia dentale professionale. Prevenzione e salute orale. Consigli dell\'igienista.',
    date: '2026-04-10',
    excerpt: 'La pulizia dentale professionale è fondamentale per mantenere denti e gengive sani. Scopri ogni quanto farla e perché è così importante.',
    category: 'Prevenzione'
  },
  {
    id: 3,
    slug: 'sbiancamento-dentale-come-funziona',
    title: 'Sbiancamento dentale: come funziona e quando farlo',
    metaTitle: 'Sbiancamento dentale: come funziona | Studio Romegialli',
    metaDescription: 'Sbiancamento professionale: procedura, risultati, durata. Quando farlo e come mantenere i risultati.',
    date: '2026-04-05',
    excerpt: 'Vuoi un sorriso più luminoso? Lo sbiancamento dentale professionale è la soluzione. Scopri come funziona, quando è indicato e come mantenere i risultati.',
    category: 'Estetica'
  },
  {
    id: 4,
    slug: 'implantologia-cosa-sapere',
    title: 'Implantologia dentale: cosa sapere prima di iniziare',
    metaTitle: 'Implantologia: guida completa | Studio Romegialli',
    metaDescription: 'Tutto su impianti dentali: procedura, durata, costi, vantaggi. Guida completa per pazienti a Morbegno.',
    date: '2026-03-28',
    excerpt: 'Gli impianti dentali sono la soluzione moderna per sostituire denti mancanti. Ecco tutto quello che devi sapere prima di iniziare un trattamento implantologico.',
    category: 'Trattamenti'
  },
  {
    id: 5,
    slug: 'mal-di-denti-cause-rimedi',
    title: 'Mal di denti: cause e quando chiamare il dentista',
    metaTitle: 'Mal di denti: cause e rimedi | Studio Romegialli',
    metaDescription: 'Cause del mal di denti e quando contattare il dentista. Rimedi temporanei e soluzioni professionali.',
    date: '2026-03-20',
    excerpt: 'Il mal di denti può avere diverse cause. Scopri quando è il momento di chiamare il dentista e cosa fare nell\'attesa.',
    category: 'Urgenze'
  },
  {
    id: 6,
    slug: 'gengive-sanguinanti-cause',
    title: 'Gengive che sanguinano: cosa significa?',
    metaTitle: 'Gengive sanguinanti: cause e cure | Studio Romegialli',
    metaDescription: 'Gengive che sanguinano: cause, significato, cure. Quando preoccuparsi e come prevenire la parodontite.',
    date: '2026-03-12',
    excerpt: 'Le gengive che sanguinano sono un segnale da non sottovalutare. Scopri le cause e come intervenire per prevenire problemi più seri.',
    category: 'Prevenzione'
  },
  {
    id: 7,
    slug: 'ortodonzia-invisibile-vantaggi',
    title: 'Ortodonzia invisibile: vantaggi e indicazioni',
    metaTitle: 'Ortodonzia invisibile: allineatori trasparenti | Studio Romegialli',
    metaDescription: 'Allineatori trasparenti: come funzionano, vantaggi, durata. Alternativa discreta all\'apparecchio tradizionale.',
    date: '2026-03-05',
    excerpt: 'Gli allineatori trasparenti stanno rivoluzionando l\'ortodonzia. Scopri come funzionano, i vantaggi e se sono adatti al tuo caso.',
    category: 'Ortodonzia'
  },
  {
    id: 8,
    slug: 'prima-visita-dentista-cosa-aspettarsi',
    title: 'Prima visita dal dentista: cosa aspettarsi',
    metaTitle: 'Prima visita dentista: cosa aspettarsi | Studio Romegialli',
    metaDescription: 'Cosa succede alla prima visita dal dentista. Accoglienza, valutazione, piano di cura personalizzato.',
    date: '2026-02-25',
    excerpt: 'La prima visita dal dentista può generare ansia. Ecco cosa aspettarti per arrivare preparato e sereno.',
    category: 'Consigli'
  },
  {
    id: 9,
    slug: 'dentista-bambini-quando-iniziare',
    title: 'Dentista per bambini: quando iniziare?',
    metaTitle: 'Dentista bambini: quando iniziare? | Studio Romegialli',
    metaDescription: 'Quando portare il bambino dal dentista. Prevenzione, educazione igiene, approccio delicato e rassicurante.',
    date: '2026-02-18',
    excerpt: 'Portare il bambino dal dentista fin da piccolo è importante per la sua salute orale futura. Scopri quando iniziare e come prepararlo.',
    category: 'Pedodonzia'
  },
  {
    id: 10,
    slug: 'prevenire-carie-consigli',
    title: 'Come prevenire le carie',
    metaTitle: 'Prevenzione carie: consigli pratici | Studio Romegialli',
    metaDescription: 'Come prevenire le carie: igiene, alimentazione, controlli. Strategie efficaci per denti sani.',
    date: '2026-02-10',
    excerpt: 'La carie è prevenibile con le giuste abitudini. Ecco i consigli pratici per mantenere i tuoi denti sani e forti.',
    category: 'Prevenzione'
  },
  {
    id: 11,
    slug: 'otturazione-vs-devitalizzazione',
    title: 'Differenza tra otturazione e devitalizzazione',
    metaTitle: 'Otturazione vs devitalizzazione | Studio Romegialli',
    metaDescription: 'Differenza tra otturazione e devitalizzazione. Quando serve quale trattamento e come funzionano.',
    date: '2026-02-02',
    excerpt: 'Otturazione e devitalizzazione sono due trattamenti diversi. Scopri quando serve l\'uno o l\'altro e come funzionano.',
    category: 'Trattamenti'
  },
  {
    id: 12,
    slug: 'mantenere-sorriso-sano',
    title: 'Come mantenere un sorriso sano nel tempo',
    metaTitle: 'Mantenere sorriso sano: guida completa | Studio Romegialli',
    metaDescription: 'Come mantenere denti sani nel tempo. Igiene, prevenzione, controlli periodici e stili di vita.',
    date: '2026-01-25',
    excerpt: 'Un sorriso sano richiede cura costante. Ecco le abitudini quotidiane e i controlli periodici per mantenerlo nel tempo.',
    category: 'Prevenzione'
  },
  {
    id: 13,
    slug: 'protesi-fisse-mobili',
    title: 'Protesi dentarie: fisse o mobili?',
    metaTitle: 'Protesi dentarie: fisse o mobili? | Studio Romegialli',
    metaDescription: 'Protesi fisse vs mobili: differenze, vantaggi, svantaggi. Quale scegliere per il tuo caso.',
    date: '2026-01-18',
    excerpt: 'Protesi fisse o mobili? Ogni soluzione ha vantaggi specifici. Scopri quale è più adatta alle tue esigenze.',
    category: 'Trattamenti'
  },
  {
    id: 14,
    slug: 'estetica-dentale-migliorare-sorriso',
    title: 'Estetica dentale: come migliorare il sorriso',
    metaTitle: 'Estetica dentale: migliorare il sorriso | Studio Romegialli',
    metaDescription: 'Trattamenti estetici dentali: sbiancamento, faccette, compositi. Come migliorare il tuo sorriso.',
    date: '2026-01-10',
    excerpt: 'L\'estetica dentale offre molte soluzioni per migliorare il tuo sorriso. Scopri i trattamenti disponibili e quale fa per te.',
    category: 'Estetica'
  },
  {
    id: 15,
    slug: 'dentista-valtellina-studio-vicino',
    title: 'Dentista in Valtellina: perché scegliere uno studio vicino',
    metaTitle: 'Dentista Valtellina: Studio Romegialli a Morbegno',
    metaDescription: 'Perché scegliere un dentista vicino a casa in Valtellina. Comodità, continuità di cura, fiducia locale.',
    date: '2026-01-03',
    excerpt: 'Scegliere un dentista vicino a casa in Valtellina offre molti vantaggi. Scopri perché la vicinanza conta per la tua salute orale.',
    category: 'Consigli'
  }
];