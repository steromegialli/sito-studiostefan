export const servicesData = [
  {
    id: 1,
    name: 'Igiene orale',
    slug: 'igiene-orale',
    description: 'Pulizia professionale e prevenzione per mantenere denti e gengive sani nel tempo.',
    icon: 'Sparkles',
    keywords: ['pulizia denti', 'igiene dentale', 'detartrasi', 'prevenzione'],
    metaTitle: 'Igiene orale Morbegno | Pulizia denti | Studio Romegialli',
    metaDescription: 'Igiene orale professionale a Morbegno. Pulizia denti, detartrasi, prevenzione. Prenota la tua seduta di igiene dentale.'
  },
  {
    id: 2,
    name: 'Sbiancamento dentale',
    slug: 'sbiancamento',
    description: 'Trattamenti professionali per un sorriso più luminoso e naturale.',
    icon: 'Sun',
    keywords: ['sbiancamento', 'denti bianchi', 'estetica'],
    metaTitle: 'Sbiancamento denti Morbegno | Studio Romegialli',
    metaDescription: 'Sbiancamento dentale professionale a Morbegno. Risultati naturali e duraturi. Prenota la tua seduta di sbiancamento.'
  },
  {
    id: 3,
    name: 'Implantologia',
    slug: 'implantologia',
    description: 'Sostituzione di denti mancanti con impianti dentali di ultima generazione.',
    icon: 'Anchor',
    keywords: ['impianti dentali', 'implantologia', 'denti fissi'],
    metaTitle: 'Implantologia Morbegno | Impianti dentali | Studio Romegialli',
    metaDescription: 'Implantologia dentale a Morbegno. Impianti di qualità, tecnologie moderne. Ritrova il tuo sorriso con soluzioni fisse.'
  },
  {
    id: 4,
    name: 'Protesi dentarie',
    slug: 'protesi',
    description: 'Protesi fisse e mobili su misura per ripristinare funzione ed estetica.',
    icon: 'Layers',
    keywords: ['protesi dentarie', 'dentiera', 'protesi fissa', 'protesi mobile'],
    metaTitle: 'Protesi dentarie Morbegno | Fisse e mobili | Studio Romegialli',
    metaDescription: 'Protesi dentarie a Morbegno: fisse, mobili, su impianti. Soluzioni personalizzate per ogni esigenza.'
  },
  {
    id: 5,
    name: 'Ortodonzia',
    slug: 'ortodonzia',
    description: 'Correzione di malocclusioni e allineamento dentale per adulti e bambini.',
    icon: 'Smile',
    keywords: ['ortodonzia', 'apparecchio', 'malocclusione', 'allineamento'],
    metaTitle: 'Ortodonzia Morbegno | Apparecchi dentali | Studio Romegialli',
    metaDescription: 'Ortodonzia a Morbegno per adulti e bambini. Apparecchi fissi, mobili, invisibili. Sorriso allineato e funzionale.'
  },
  {
    id: 6,
    name: 'Ortodonzia invisibile',
    slug: 'ortodonzia-invisibile',
    description: 'Allineatori trasparenti per correggere la posizione dei denti in modo discreto.',
    icon: 'Eye',
    keywords: ['ortodonzia invisibile', 'allineatori', 'invisalign', 'apparecchio trasparente'],
    metaTitle: 'Ortodonzia invisibile Morbegno | Allineatori | Studio Romegialli',
    metaDescription: 'Ortodonzia invisibile a Morbegno. Allineatori trasparenti per adulti. Sorriso perfetto senza apparecchio visibile.'
  },
  {
    id: 7,
    name: 'Estetica dentale',
    slug: 'estetica-dentale',
    description: 'Faccette, compositi e trattamenti estetici per migliorare il tuo sorriso.',
    icon: 'Star',
    keywords: ['estetica dentale', 'faccette', 'compositi', 'sorriso perfetto'],
    metaTitle: 'Estetica dentale Morbegno | Faccette | Studio Romegialli',
    metaDescription: 'Estetica dentale a Morbegno. Faccette, compositi, sbiancamento. Migliora il tuo sorriso con trattamenti personalizzati.'
  },
  {
    id: 8,
    name: 'Endodonzia',
    slug: 'endodonzia',
    description: 'Devitalizzazione e trattamenti canalari per salvare denti compromessi.',
    icon: 'Activity',
    keywords: ['endodonzia', 'devitalizzazione', 'cura canalare', 'mal di denti'],
    metaTitle: 'Endodonzia Morbegno | Devitalizzazione | Studio Romegialli',
    metaDescription: 'Endodonzia a Morbegno. Devitalizzazione e cure canalari con tecnologie moderne. Salva il tuo dente naturale.'
  },
  {
    id: 9,
    name: 'Odontoiatria conservativa',
    slug: 'odontoiatria-conservativa',
    description: 'Otturazioni e ricostruzioni per preservare i denti naturali.',
    icon: 'Shield',
    keywords: ['otturazioni', 'carie', 'ricostruzioni', 'conservativa'],
    metaTitle: 'Odontoiatria conservativa Morbegno | Otturazioni | Studio Romegialli',
    metaDescription: 'Odontoiatria conservativa a Morbegno. Otturazioni estetiche, cura delle carie. Preserva i tuoi denti naturali.'
  },
  {
    id: 10,
    name: 'Parodontologia',
    slug: 'parodontologia',
    description: 'Cura e prevenzione delle malattie gengivali e del supporto dentale.',
    icon: 'Heart',
    keywords: ['parodontologia', 'gengive', 'parodontite', 'gengivite'],
    metaTitle: 'Parodontologia Morbegno | Cura gengive | Studio Romegialli',
    metaDescription: 'Parodontologia a Morbegno. Cura di gengive e parodontite. Prevenzione e trattamenti specialistici.'
  },
  {
    id: 11,
    name: 'Pedodonzia',
    slug: 'pedodonzia',
    description: 'Odontoiatria pediatrica con approccio delicato e rassicurante.',
    icon: 'Baby',
    keywords: ['pedodonzia', 'dentista bambini', 'odontoiatria pediatrica'],
    metaTitle: 'Pedodonzia Morbegno | Dentista bambini | Studio Romegialli',
    metaDescription: 'Pedodonzia a Morbegno. Dentista per bambini con approccio delicato. Prevenzione e cura dei denti da latte.'
  },
  {
    id: 12,
    name: 'Prima visita odontoiatrica',
    slug: 'prima-visita-odontoiatrica',
    description: 'Valutazione completa dello stato di salute orale e piano di cura personalizzato.',
    icon: 'Stethoscope',
    keywords: ['prima visita', 'visita dentistica', 'controllo', 'diagnosi'],
    metaTitle: 'Prima visita dentista Morbegno | Studio Romegialli',
    metaDescription: 'Prima visita odontoiatrica a Morbegno. Valutazione completa, piano di cura personalizzato. Prenota il tuo controllo.'
  }
];