import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Calendar, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import FaqAccordion from '@/components/FaqAccordion';
import CtaSection from '@/components/CtaSection';
import { formatDate } from '@/utils/formatters';
import { generateArticleSchema, generateBreadcrumbSchema } from '@/utils/seoHelpers';

const BlogArticleTemplate = ({ article, children, faqs }) => {
  const breadcrumbs = [
    { name: 'Home', url: 'https://studioromegialli.it' },
    { name: 'Blog', url: 'https://studioromegialli.it/blog' },
    { name: article.title, url: `https://studioromegialli.it/blog/${article.slug}` }
  ];

  return (
    <>
      <Helmet>
        <title>{article.metaTitle}</title>
        <meta name="description" content={article.metaDescription} />
        <meta property="og:title" content={article.metaTitle} />
        <meta property="og:description" content={article.metaDescription} />
        <meta property="og:type" content="article" />
        <meta property="og:url" content={`https://studioromegialli.it/blog/${article.slug}`} />
        <link rel="canonical" href={`https://studioromegialli.it/blog/${article.slug}`} />
        <script type="application/ld+json">
          {JSON.stringify(generateArticleSchema(article))}
        </script>
        <script type="application/ld+json">
          {JSON.stringify(generateBreadcrumbSchema(breadcrumbs))}
        </script>
      </Helmet>

      <Header />

      <main className="pt-20">
        <article className="py-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <Button asChild variant="ghost" className="mb-8">
              <Link to="/blog">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Torna al blog
              </Link>
            </Button>

            <div className="mb-8">
              <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-4">
                <span className="px-3 py-1 rounded-full bg-primary/10 text-primary font-medium">
                  {article.category}
                </span>
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4" />
                  <time dateTime={article.date}>{formatDate(article.date)}</time>
                </div>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-4 text-balance" style={{letterSpacing: '-0.02em'}}>
                {article.title}
              </h1>
              <p className="text-xl text-muted-foreground leading-relaxed">
                {article.excerpt}
              </p>
            </div>

            <div className="prose prose-lg max-w-none">
              {children}
            </div>

            {faqs && faqs.length > 0 && (
              <div className="mt-16">
                <h2 className="text-3xl font-bold mb-8">Domande frequenti</h2>
                <FaqAccordion faqs={faqs} />
              </div>
            )}
          </div>
        </article>

        <CtaSection
          title="Hai bisogno di una consulenza?"
          description="Prenota una visita presso il nostro studio a Morbegno per ricevere una valutazione personalizzata."
        />
      </main>

      <Footer />
    </>
  );
};

export default BlogArticleTemplate;