import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Sparkles } from 'lucide-react';
import AnimatedText from './AnimatedText';
import NeonButton from './NeonButton';

const FuturisticHero = () => {
  return (
    <section className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden bg-background">
      {/* Background Image/Video Fallback */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background z-10" />
        <img 
          src="https://images.unsplash.com/photo-1616391182219-e080b4d1043a" 
          alt="Futuristic Dental Clinic" 
          className="w-full h-full object-cover opacity-40"
        />
      </div>

      {/* Animated Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[100px] animate-float" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/20 rounded-full blur-[100px] animate-float" style={{ animationDelay: '2s' }} />

      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-effect mb-8"
        >
          <Sparkles className="w-4 h-4 text-secondary" />
          <span className="text-sm font-medium text-secondary">Il futuro dell'odontoiatria è qui</span>
        </motion.div>

        <AnimatedText 
          text="Dentista a Morbegno Studio Romegialli" 
          className="text-5xl md:text-7xl font-extrabold mb-6 justify-center neon-text-primary"
        />
        
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.8 }}
          className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto mb-10 leading-relaxed"
        >
          Tecnologie all'avanguardia, design immersivo e cure personalizzate per un sorriso perfetto.
        </motion.p>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.8 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-6"
        >
          <NeonButton to="/contatti" variant="primary">
            Prenota una visita <ArrowRight className="w-4 h-4" />
          </NeonButton>
          <NeonButton href="tel:+390342612345" variant="accent">
            Chiama ora
          </NeonButton>
        </motion.div>
      </div>
    </section>
  );
};

export default FuturisticHero;