import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Sparkles, Sun, Anchor, Layers, Smile, Eye, Star, Activity, Shield, Heart, Baby, Stethoscope } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const iconMap = {
  Sparkles,
  Sun,
  Anchor,
  Layers,
  Smile,
  Eye,
  Star,
  Activity,
  Shield,
  Heart,
  Baby,
  Stethoscope
};

const ServiceCard = ({ service, index }) => {
  const Icon = iconMap[service.icon] || Sparkles;

  return (
    <Card className="group h-full hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-border/50">
      <CardContent className="p-6 flex flex-col h-full">
        <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary group-hover:scale-110 transition-all duration-300">
          <Icon className="w-7 h-7 text-primary group-hover:text-white transition-colors duration-300" />
        </div>
        <h3 className="text-xl font-semibold mb-3 text-balance">{service.name}</h3>
        <p className="text-muted-foreground leading-relaxed mb-6 flex-grow">
          {service.description}
        </p>
        <Button asChild variant="ghost" className="mt-auto w-full justify-between group/btn">
          <Link to={`/servizi/${service.slug}`}>
            Scopri di più
            <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform duration-200" />
          </Link>
        </Button>
      </CardContent>
    </Card>
  );
};

export default ServiceCard;