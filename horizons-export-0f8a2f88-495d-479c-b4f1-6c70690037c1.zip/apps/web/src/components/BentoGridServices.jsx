import React from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight, Activity, Shield, Sparkles, Anchor } from 'lucide-react';
import GlassCard from './GlassCard';
import { Link } from 'react-router-dom';

const BentoGridServices = () => {
  const services = [
    {
      title: "Implantologia Avanzata",
      desc: "Soluzioni fisse con tecnologie 3D per risultati perfetti e duraturi.",
      icon: Anchor,
      colSpan: "md:col-span-2",
      rowSpan: "md:row-span-2",
      color: "text-primary",
      link: "/servizi/implantologia"
    },
    {
      title: "Estetica Dentale",
      desc: "Faccette e sbiancamento laser.",
      icon: Sparkles,
      colSpan: "md:col-span-1",
      rowSpan: "md:row-span-1",
      color: "text-secondary",
      link: "/servizi/estetica-dentale"
    },
    {
      title: "Ortodonzia Invisibile",
      desc: "Allineatori trasparenti su misura.",
      icon: Activity,
      colSpan: "md:col-span-1",
      rowSpan: "md:row-span-1",
      color: "text-accent",
      link: "/servizi/ortodonzia-invisibile"
    },
    {
      title: "Prevenzione & Igiene",
      desc: "Protocolli avanzati per la salute gengivale.",
      icon: Shield,
      colSpan: "md:col-span-2",
      rowSpan: "md:row-span-1",
      color: "text-primary",
      link: "/servizi/igiene-orale"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
      {services.map((srv, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: i * 0.1 }}
          className={`${srv.colSpan} ${srv.rowSpan}`}
        >
          <Link to={srv.link} className="block h-full">
            <GlassCard className="h-full flex flex-col justify-between group hover:border-primary/50 transition-colors">
              <div className="flex justify-between items-start mb-8">
                <div className={`p-3 rounded-xl bg-white/5 ${srv.color}`}>
                  <srv.icon className="w-8 h-8" />
                </div>
                <ArrowUpRight className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors" />
              </div>
              <div>
                <h3 className="text-2xl font-bold mb-2 text-white">{srv.title}</h3>
                <p className="text-muted-foreground">{srv.desc}</p>
              </div>
            </GlassCard>
          </Link>
        </motion.div>
      ))}
    </div>
  );
};

export default BentoGridServices;