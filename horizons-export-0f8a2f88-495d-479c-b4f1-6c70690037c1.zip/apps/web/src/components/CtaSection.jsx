import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Phone, Calendar } from 'lucide-react';

const CtaSection = ({ 
  title = 'Prenota la tua visita',
  description = 'Contattaci per fissare un appuntamento o per ricevere maggiori informazioni.',
  primaryText = 'Prenota ora',
  primaryLink = '/contatti',
  secondaryText = 'Chiama ora',
  secondaryLink = 'tel:+390342612345',
  className = ''
}) => {
  return (
    <section className={`py-20 bg-primary text-primary-foreground ${className}`}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
          {title}
        </h2>
        <p className="text-lg mb-8 text-primary-foreground/90 max-w-2xl mx-auto leading-relaxed">
          {description}
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Button asChild size="lg" variant="secondary" className="min-w-[200px]">
            <Link to={primaryLink}>
              <Calendar className="w-5 h-5 mr-2" />
              {primaryText}
            </Link>
          </Button>
          <Button asChild size="lg" variant="outline" className="min-w-[200px] bg-white/10 border-white/20 text-white hover:bg-white/20">
            <a href={secondaryLink}>
              <Phone className="w-5 h-5 mr-2" />
              {secondaryText}
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default CtaSection;