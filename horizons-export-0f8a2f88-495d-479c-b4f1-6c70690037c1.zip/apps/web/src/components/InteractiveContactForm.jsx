import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';

const InteractiveContactForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: '',
    message: '',
    privacy: false
  });
  
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // Load from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('contactFormDraft');
    if (saved) {
      try {
        setFormData(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to parse saved form data');
      }
    }
  }, []);

  // Save to localStorage on change
  useEffect(() => {
    localStorage.setItem('contactFormDraft', JSON.stringify(formData));
  }, [formData]);

  const validateField = (name, value) => {
    switch (name) {
      case 'name': return value.length < 2 ? 'Nome troppo corto' : '';
      case 'email': return !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) ? 'Email non valida' : '';
      case 'phone': return value.length < 9 ? 'Numero non valido' : '';
      case 'message': return value.length < 10 ? 'Messaggio troppo corto' : '';
      case 'privacy': return !value ? 'Devi accettare la privacy policy' : '';
      default: return '';
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    const val = type === 'checkbox' ? checked : value;
    setFormData(prev => ({ ...prev, [name]: val }));
    
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: validateField(name, val) }));
    }
  };

  const handleBlur = (e) => {
    const { name, value, type, checked } = e.target;
    const val = type === 'checkbox' ? checked : value;
    setErrors(prev => ({ ...prev, [name]: validateField(name, val) }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const newErrors = {};
    Object.keys(formData).forEach(key => {
      if (key !== 'service') {
        newErrors[key] = validateField(key, formData[key]);
      }
    });
    
    setErrors(newErrors);
    
    if (Object.values(newErrors).some(err => err !== '')) {
      return;
    }

    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsSubmitting(false);
    setIsSuccess(true);
    localStorage.removeItem('contactFormDraft');
    setFormData({ name: '', email: '', phone: '', service: '', message: '', privacy: false });
    
    setTimeout(() => setIsSuccess(false), 5000);
  };

  const inputClasses = "w-full bg-input/50 border border-border rounded-xl px-4 py-3 text-white placeholder:text-muted-foreground focus:border-primary focus:ring-1 focus:ring-primary transition-all duration-300";

  return (
    <div className="glass-effect rounded-3xl p-8 md:p-12 relative overflow-hidden">
      <AnimatePresence>
        {isSuccess && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="absolute inset-0 z-50 bg-card/95 backdrop-blur-sm flex flex-col items-center justify-center rounded-3xl"
          >
            <motion.div 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", damping: 12, delay: 0.2 }}
              className="w-20 h-20 rounded-full bg-accent/20 flex items-center justify-center mb-6"
            >
              <CheckCircle2 className="w-10 h-10 text-accent" />
            </motion.div>
            <h3 className="text-3xl font-bold text-white mb-2">Messaggio Inviato!</h3>
            <p className="text-muted-foreground text-center max-w-md">
              Grazie per averci contattato. Il nostro team ti risponderà il prima possibile.
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      <form onSubmit={handleSubmit} className="space-y-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <motion.div animate={errors.name ? { x: [-5, 5, -5, 5, 0] } : {}}>
            <label className="block text-sm font-medium text-muted-foreground mb-2">Nome Completo</label>
            <div className="relative">
              <input 
                type="text" name="name" value={formData.name} onChange={handleChange} onBlur={handleBlur}
                className={`${inputClasses} ${errors.name ? 'border-destructive focus:border-destructive focus:ring-destructive' : ''}`}
                placeholder="Mario Rossi"
              />
              {formData.name && !errors.name && <CheckCircle2 className="absolute right-3 top-3.5 w-5 h-5 text-accent" />}
              {errors.name && <AlertCircle className="absolute right-3 top-3.5 w-5 h-5 text-destructive" />}
            </div>
          </motion.div>

          <motion.div animate={errors.email ? { x: [-5, 5, -5, 5, 0] } : {}}>
            <label className="block text-sm font-medium text-muted-foreground mb-2">Email</label>
            <div className="relative">
              <input 
                type="email" name="email" value={formData.email} onChange={handleChange} onBlur={handleBlur}
                className={`${inputClasses} ${errors.email ? 'border-destructive focus:border-destructive focus:ring-destructive' : ''}`}
                placeholder="mario@esempio.it"
              />
              {formData.email && !errors.email && <CheckCircle2 className="absolute right-3 top-3.5 w-5 h-5 text-accent" />}
              {errors.email && <AlertCircle className="absolute right-3 top-3.5 w-5 h-5 text-destructive" />}
            </div>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <motion.div animate={errors.phone ? { x: [-5, 5, -5, 5, 0] } : {}}>
            <label className="block text-sm font-medium text-muted-foreground mb-2">Telefono</label>
            <div className="relative">
              <input 
                type="tel" name="phone" value={formData.phone} onChange={handleChange} onBlur={handleBlur}
                className={`${inputClasses} ${errors.phone ? 'border-destructive focus:border-destructive focus:ring-destructive' : ''}`}
                placeholder="+39 333 1234567"
              />
            </div>
          </motion.div>

          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">Servizio di Interesse</label>
            <select 
              name="service" value={formData.service} onChange={handleChange}
              className={inputClasses}
            >
              <option value="" disabled>Seleziona un servizio</option>
              <option value="prima-visita">Prima Visita</option>
              <option value="implantologia">Implantologia</option>
              <option value="ortodonzia">Ortodonzia</option>
              <option value="estetica">Estetica Dentale</option>
              <option value="altro">Altro</option>
            </select>
          </div>
        </div>

        <motion.div animate={errors.message ? { x: [-5, 5, -5, 5, 0] } : {}}>
          <label className="block text-sm font-medium text-muted-foreground mb-2">Messaggio</label>
          <textarea 
            name="message" rows="4" value={formData.message} onChange={handleChange} onBlur={handleBlur}
            className={`${inputClasses} resize-none ${errors.message ? 'border-destructive focus:border-destructive focus:ring-destructive' : ''}`}
            placeholder="Come possiamo aiutarti?"
          />
        </motion.div>

        <motion.div animate={errors.privacy ? { x: [-5, 5, -5, 5, 0] } : {}} className="flex items-start gap-3">
          <input 
            type="checkbox" id="privacy" name="privacy" checked={formData.privacy} onChange={handleChange}
            className="mt-1 w-5 h-5 rounded border-border bg-input/50 text-primary focus:ring-primary"
          />
          <label htmlFor="privacy" className="text-sm text-muted-foreground">
            Accetto il trattamento dei dati personali secondo la <a href="/privacy" className="text-primary hover:underline">Privacy Policy</a>.
          </label>
        </motion.div>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          disabled={isSubmitting}
          type="submit"
          className="w-full py-4 rounded-xl bg-primary text-white font-semibold text-lg hover:bg-secondary transition-colors duration-300 flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-6 h-6 animate-spin" />
              Invio in corso...
            </>
          ) : (
            'Invia Richiesta'
          )}
        </motion.button>
      </form>
    </div>
  );
};

export default InteractiveContactForm;