import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';

const AnimatedTimeline = ({ steps }) => {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start center", "end center"]
  });

  const lineHeight = useTransform(scrollYProgress, [0, 1], ["0%", "100%"]);

  return (
    <div ref={containerRef} className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
      {/* Animated Vertical Line */}
      <div className="absolute left-[28px] md:left-1/2 top-0 bottom-0 w-1 bg-border rounded-full overflow-hidden">
        <motion.div 
          style={{ height: lineHeight }}
          className="w-full bg-gradient-to-b from-primary via-secondary to-accent"
        />
      </div>

      <div className="space-y-24">
        {steps.map((step, index) => {
          const isEven = index % 2 === 0;
          
          return (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className={`relative flex flex-col md:flex-row items-start ${isEven ? 'md:flex-row-reverse' : ''}`}
            >
              {/* Icon Node */}
              <div className="absolute left-0 md:left-1/2 -translate-x-0 md:-translate-x-1/2 flex items-center justify-center w-14 h-14 rounded-full glass-effect border-2 border-primary bg-background z-10">
                <motion.div
                  whileInView={{ rotate: 360 }}
                  viewport={{ once: true }}
                  transition={{ duration: 1, delay: 0.3 }}
                >
                  <step.icon className="w-6 h-6 text-primary" />
                </motion.div>
              </div>

              {/* Content */}
              <div className={`ml-20 md:ml-0 md:w-1/2 ${isEven ? 'md:pl-16' : 'md:pr-16 text-left md:text-right'}`}>
                <div className="glass-effect p-8 rounded-3xl hover:border-primary/50 transition-colors duration-300 group">
                  <span className="inline-block px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-semibold mb-4">
                    Fase {index + 1}
                  </span>
                  <h3 className="text-2xl font-bold mb-3 text-white group-hover:text-secondary transition-colors">{step.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{step.description}</p>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};

export default AnimatedTimeline;