import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const TeamMemberCard = ({ member }) => {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <CardContent className="p-0">
        <div className="aspect-square bg-muted relative overflow-hidden">
          <Avatar className="w-full h-full rounded-none">
            <AvatarImage src={member.image} alt={member.name} className="object-cover" />
            <AvatarFallback className="rounded-none bg-primary/10 text-primary text-4xl font-bold">
              {member.initials}
            </AvatarFallback>
          </Avatar>
        </div>
        <div className="p-6">
          <h3 className="text-xl font-semibold mb-1">{member.name}</h3>
          <p className="text-sm font-medium text-primary mb-3">{member.role}</p>
          <p className="text-sm text-muted-foreground leading-relaxed">
            {member.bio}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default TeamMemberCard;