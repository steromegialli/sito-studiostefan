import React from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { ChevronDown } from 'lucide-react';
import { Link } from 'react-router-dom';

const HeroSection = ({ 
  title, 
  subtitle, 
  buttons, 
  videoUrl, 
  overlayGradient = "bg-gradient-to-b from-background/40 via-background/60 to-background" 
}) => {
  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 1000], [0, 200]);
  const y2 = useTransform(scrollY, [0, 1000], [0, -100]);
  const opacity = useTransform(scrollY, [0, 500], [1, 0]);

  const titleWords = title.split(" ");

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 }
    }
  };

  const wordVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { type: "spring", damping: 12, stiffness: 100 }
    }
  };

  return (
    <section className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden bg-background">
      {/* Video Background */}
      <div className="absolute inset-0 z-0">
        <div className={`absolute inset-0 z-10 ${overlayGradient}`} />
        <motion.img 
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 0.4, scale: 1 }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          src={videoUrl} 
          alt="Hero Background" 
          className="w-full h-full object-cover"
        />
      </div>

      <motion.div 
        style={{ y: y1, opacity }}
        className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mt-20"
      >
        <motion.h1 
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="text-5xl md:text-7xl lg:text-8xl font-extrabold mb-6 flex flex-wrap justify-center gap-x-4"
        >
          {titleWords.map((word, i) => (
            <motion.span key={i} variants={wordVariants} className="text-white">
              {word}
            </motion.span>
          ))}
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.8, ease: [0.165, 0.84, 0.44, 1] }}
          className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto mb-12 leading-relaxed"
        >
          {subtitle}
        </motion.p>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.8 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-6"
        >
          {buttons.map((btn, i) => (
            <motion.div
              key={i}
              whileHover={{ scale: 1.05, boxShadow: `0 0 20px ${btn.primary ? 'hsl(var(--primary)/0.5)' : 'hsl(var(--foreground)/0.2)'}` }}
              whileTap={{ scale: 0.98 }}
            >
              <Link 
                to={btn.link}
                className={`px-8 py-4 rounded-full font-semibold transition-colors duration-300 flex items-center gap-2 ${
                  btn.primary 
                    ? 'bg-primary text-primary-foreground hover:bg-secondary hover:text-secondary-foreground' 
                    : 'glass-effect text-foreground hover:bg-white/10'
                }`}
              >
                {btn.text}
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </motion.div>

      <motion.div 
        style={{ y: y2, opacity }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
          className="w-10 h-16 rounded-full border-2 border-white/20 flex items-start justify-center p-2 glass-effect"
        >
          <motion.div 
            animate={{ y: [0, 16, 0], opacity: [1, 0, 1] }}
            transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
            className="w-1.5 h-3 bg-primary rounded-full"
          />
        </motion.div>
      </motion.div>
    </section>
  );
};

export default HeroSection;