import React from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const ServiceCard = ({ service, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.6, delay: index * 0.1, ease: [0.165, 0.84, 0.44, 1] }}
      className={`group relative overflow-hidden rounded-3xl glass-effect ${service.colSpan} ${service.rowSpan}`}
    >
      <Link to={service.link} className="block h-full p-8 flex flex-col justify-between z-10 relative">
        <div className="flex justify-between items-start mb-12">
          <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center group-hover:bg-primary/20 transition-colors duration-500">
            <service.icon className="w-7 h-7 text-primary group-hover:text-secondary transition-colors duration-500 group-hover:rotate-12" />
          </div>
          <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center opacity-0 -translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-500">
            <ArrowUpRight className="w-5 h-5 text-white" />
          </div>
        </div>
        
        <div className="relative z-10">
          <h3 className="text-2xl font-bold mb-3 text-white group-hover:text-secondary transition-colors duration-300">{service.title}</h3>
          <p className="text-muted-foreground group-hover:text-white/90 transition-colors duration-300 line-clamp-2">{service.desc}</p>
        </div>
      </Link>

      {/* Hover Background Effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
      
      {/* Optional Image Parallax */}
      {service.image && (
        <div className="absolute inset-0 z-0 opacity-20 group-hover:opacity-40 transition-opacity duration-700 overflow-hidden">
          <img 
            src={service.image} 
            alt={service.title} 
            className="w-full h-full object-cover scale-100 group-hover:scale-110 transition-transform duration-1000"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
        </div>
      )}
    </motion.div>
  );
};

const AnimatedServiceGrid = ({ services }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {services.map((service, index) => (
        <ServiceCard key={index} service={service} index={index} />
      ))}
    </div>
  );
};

export default AnimatedServiceGrid;