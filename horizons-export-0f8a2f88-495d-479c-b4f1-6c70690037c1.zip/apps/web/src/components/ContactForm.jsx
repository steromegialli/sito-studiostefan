import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';

const ContactForm = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    email: '',
    reason: '',
    message: '',
    privacy: false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.privacy) {
      toast.error('Devi accettare la privacy policy per continuare');
      return;
    }

    setIsSubmitting(true);
    
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    toast.success('Messaggio inviato. Ti contatteremo presto.');
    
    setFormData({
      firstName: '',
      lastName: '',
      phone: '',
      email: '',
      reason: '',
      message: '',
      privacy: false
    });
    
    setIsSubmitting(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="firstName">Nome *</Label>
          <Input
            id="firstName"
            type="text"
            required
            value={formData.firstName}
            onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
            className="text-foreground placeholder:text-muted-foreground"
            placeholder="Il tuo nome"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="lastName">Cognome *</Label>
          <Input
            id="lastName"
            type="text"
            required
            value={formData.lastName}
            onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
            className="text-foreground placeholder:text-muted-foreground"
            placeholder="Il tuo cognome"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="phone">Telefono *</Label>
          <Input
            id="phone"
            type="tel"
            required
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            className="text-foreground placeholder:text-muted-foreground"
            placeholder="Il tuo numero di telefono"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="email">Email *</Label>
          <Input
            id="email"
            type="email"
            required
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            className="text-foreground placeholder:text-muted-foreground"
            placeholder="La tua email"
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="reason">Motivo del contatto *</Label>
        <Select
          value={formData.reason}
          onValueChange={(value) => setFormData({ ...formData, reason: value })}
          required
        >
          <SelectTrigger id="reason" className="text-foreground">
            <SelectValue placeholder="Seleziona un motivo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="prima-visita">Prima visita</SelectItem>
            <SelectItem value="urgenza">Urgenza</SelectItem>
            <SelectItem value="preventivo">Richiesta preventivo</SelectItem>
            <SelectItem value="informazioni">Informazioni generali</SelectItem>
            <SelectItem value="altro">Altro</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="message">Messaggio *</Label>
        <Textarea
          id="message"
          required
          rows={5}
          value={formData.message}
          onChange={(e) => setFormData({ ...formData, message: e.target.value })}
          className="text-foreground placeholder:text-muted-foreground resize-none"
          placeholder="Scrivi qui il tuo messaggio..."
        />
      </div>

      <div className="flex items-start space-x-3">
        <Checkbox
          id="privacy"
          checked={formData.privacy}
          onCheckedChange={(checked) => setFormData({ ...formData, privacy: checked })}
          required
        />
        <Label htmlFor="privacy" className="text-sm leading-relaxed cursor-pointer">
          Accetto la{' '}
          <a href="/privacy" className="text-primary hover:underline">
            privacy policy
          </a>{' '}
          e autorizzo il trattamento dei miei dati personali *
        </Label>
      </div>

      <Button
        type="submit"
        size="lg"
        className="w-full md:w-auto"
        disabled={isSubmitting}
      >
        {isSubmitting ? 'Invio in corso...' : 'Invia messaggio'}
      </Button>
    </form>
  );
};

export default ContactForm;