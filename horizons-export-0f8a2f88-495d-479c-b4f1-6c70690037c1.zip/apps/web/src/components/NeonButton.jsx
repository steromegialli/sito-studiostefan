import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';

const NeonButton = ({ children, to, href, onClick, variant = 'primary', className, ...props }) => {
  const baseStyles = "relative inline-flex items-center justify-center px-8 py-3 font-medium tracking-wide text-white transition-all duration-300 rounded-full overflow-hidden group";
  
  const variants = {
    primary: "bg-primary/20 border border-primary/50 hover:bg-primary/40 hover:border-primary",
    secondary: "bg-secondary/20 border border-secondary/50 hover:bg-secondary/40 hover:border-secondary text-secondary-foreground",
    accent: "bg-accent/20 border border-accent/50 hover:bg-accent/40 hover:border-accent",
  };

  const glowColors = {
    primary: "0 0 20px hsl(var(--primary) / 0.5)",
    secondary: "0 0 20px hsl(var(--secondary) / 0.5)",
    accent: "0 0 20px hsl(var(--accent) / 0.5)",
  };

  const content = (
    <>
      <span className="relative z-10 flex items-center gap-2">{children}</span>
      <div className="absolute inset-0 -z-10 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700" />
    </>
  );

  const motionProps = {
    whileHover: { scale: 1.02, boxShadow: glowColors[variant] },
    whileTap: { scale: 0.98 },
    className: cn(baseStyles, variants[variant], className),
    onClick,
    ...props
  };

  if (to) {
    return <motion.div {...motionProps}><Link to={to} className="w-full h-full flex items-center justify-center">{content}</Link></motion.div>;
  }

  if (href) {
    return <motion.a href={href} {...motionProps}>{content}</motion.a>;
  }

  return <motion.button {...motionProps}>{content}</motion.button>;
};

export default NeonButton;