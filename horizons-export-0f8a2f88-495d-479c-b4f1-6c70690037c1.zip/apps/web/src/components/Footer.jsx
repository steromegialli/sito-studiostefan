import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Phone, Mail, Clock, Facebook, Instagram, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { name: 'Chi siamo', path: '/chi-siamo' },
    { name: 'Servizi', path: '/servizi' },
    { name: 'Contatti', path: '/contatti' }
  ];

  const services = [
    { name: 'Igiene orale', path: '/servizi' },
    { name: 'Implantologia', path: '/servizi' },
    { name: 'Ortodonzia', path: '/servizi' },
    { name: 'Estetica Dentale', path: '/servizi' }
  ];

  return (
    <footer className="relative bg-background pt-24 pb-12 overflow-hidden border-t border-border">
      {/* Animated Gradient Background */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <div className="absolute -top-[50%] -left-[10%] w-[70%] h-[100%] rounded-full bg-primary blur-[120px] mix-blend-screen animate-pulse" />
        <div className="absolute -bottom-[50%] -right-[10%] w-[70%] h-[100%] rounded-full bg-secondary blur-[120px] mix-blend-screen animate-pulse delay-1000" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand Column */}
          <div className="space-y-6">
            <div className="text-3xl font-bold text-white">
              Studio Romegialli
            </div>
            <p className="text-muted-foreground leading-relaxed">
              Eccellenza odontoiatrica a Morbegno. Uniamo tecnologie all'avanguardia a un approccio umano e personalizzato.
            </p>
            <div className="flex space-x-4">
              {[Facebook, Instagram].map((Icon, i) => (
                <motion.a
                  key={i}
                  whileHover={{ scale: 1.1, rotate: 5, backgroundColor: 'hsl(var(--primary))' }}
                  href="#"
                  className="w-10 h-10 rounded-full glass-effect flex items-center justify-center text-white transition-colors"
                >
                  <Icon className="w-5 h-5" />
                </motion.a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-6">Esplora</h4>
            <ul className="space-y-4">
              {quickLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-muted-foreground hover:text-primary transition-colors duration-300 flex items-center group"
                  >
                    <ArrowRight className="w-4 h-4 mr-2 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-6">Servizi</h4>
            <ul className="space-y-4">
              {services.map((service, i) => (
                <li key={i}>
                  <Link
                    to={service.path}
                    className="text-muted-foreground hover:text-secondary transition-colors duration-300 flex items-center group"
                  >
                    <ArrowRight className="w-4 h-4 mr-2 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                    {service.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-6">Contatti</h4>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3 text-muted-foreground">
                <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                <span>Via Roma 15<br />23017 Morbegno (SO)</span>
              </li>
              <li className="flex items-center space-x-3 text-muted-foreground">
                <Phone className="w-5 h-5 text-primary flex-shrink-0" />
                <a href="tel:+390342612345" className="hover:text-white transition-colors">0342 612345</a>
              </li>
              <li className="flex items-center space-x-3 text-muted-foreground">
                <Mail className="w-5 h-5 text-primary flex-shrink-0" />
                <a href="mailto:info@studioromegialli.it" className="hover:text-white transition-colors">info@studioromegialli.it</a>
              </li>
              <li className="flex items-start space-x-3 text-muted-foreground">
                <Clock className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                <span>Lun-Ven: 9:00 - 19:00<br />Sab: 9:00 - 13:00</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-muted-foreground text-sm">
            © <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1 }}>{currentYear}</motion.span> Studio Romegialli. Tutti i diritti riservati.
          </p>
          <div className="flex space-x-6 text-sm text-muted-foreground">
            <Link to="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link>
            <Link to="/cookie" className="hover:text-white transition-colors">Cookie Policy</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;