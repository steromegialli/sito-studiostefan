import React from 'react';
import { Star } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const ReviewCard = ({ review }) => {
  return (
    <Card className="h-full">
      <CardContent className="p-6">
        <div className="flex items-center space-x-1 mb-4">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className={`w-5 h-5 ${
                i < review.rating
                  ? 'fill-amber-400 text-amber-400'
                  : 'text-gray-300'
              }`}
            />
          ))}
        </div>
        <p className="text-foreground/90 leading-relaxed mb-6 italic">
          "{review.text}"
        </p>
        <div className="flex items-center space-x-3">
          <Avatar className="w-12 h-12 rounded-xl">
            <AvatarImage src={review.image} alt={review.name} />
            <AvatarFallback className="rounded-xl bg-primary/10 text-primary font-semibold">
              {review.initials}
            </AvatarFallback>
          </Avatar>
          <div>
            <p className="font-semibold">{review.name}</p>
            <p className="text-sm text-muted-foreground">{review.location}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ReviewCard;